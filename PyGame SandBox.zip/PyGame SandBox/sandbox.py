import pygame
import json
import os

pygame.init()

# --- SETTINGS ---
TILE_SIZE = 32
WORLD_WIDTH = 100
WORLD_HEIGHT = 100
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame Sandbox")

clock = pygame.time.Clock()
FONT = pygame.font.SysFont("Arial", 32)

# --- BLOCK COLORS ---
BLOCKS = {
    0: (0, 0, 0),          # empty
    1: (139, 69, 19),      # dirt
    2: (34, 139, 34),      # grass
    3: (128, 128, 128),    # stone
    4: (194, 178, 128),    # sand
    5: (0, 0, 255)         # water
}

# Inventory slots (block IDs)
inventory = [1, 2, 3, 4, 5]
selected_slot = 0

# --- GAME STATE ---
state = "menu"
world = None
camera_x = 0
camera_y = 0

scroll_offset = 0
scroll_speed = 40  # pixels per scroll


# -------------------------------
# WORLD FUNCTIONS
# -------------------------------

def new_world():
    return [[0 for _ in range(WORLD_WIDTH)] for _ in range(WORLD_HEIGHT)]


def save_world(filename, world_data):
    data = {"world": world_data}
    with open("worlds/" + filename, "w") as f:
        json.dump(data, f)
    print("Saved:", filename)


def load_world(filename):
    with open("worlds/" + filename, "r") as f:
        data = json.load(f)
        return data["world"]


def get_world_list():
    if not os.path.exists("worlds"):
        os.makedirs("worlds")
    files = os.listdir("worlds")
    return [f for f in files if f.endswith(".json")]


# -------------------------------
# MENU DRAWING
# -------------------------------

def draw_menu():
    screen.fill((30, 30, 30))

    title = FONT.render("Select a World", True, (255, 255, 255))
    screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 40))

    worlds = get_world_list()

    y = 120 + scroll_offset
    for world_file in worlds:
        rect = pygame.Rect(200, y, 400, 40)

        # Hover highlight
        if rect.collidepoint(pygame.mouse.get_pos()):
            pygame.draw.rect(screen, (70, 70, 70), rect)
        else:
            pygame.draw.rect(screen, (50, 50, 50), rect)

        text = FONT.render(world_file, True, (200, 200, 200))
        screen.blit(text, (rect.x + 10, rect.y + 5))

        y += 60

    # New world button
    new_rect = pygame.Rect(200, SCREEN_HEIGHT - 100, 400, 50)
    pygame.draw.rect(screen, (80, 80, 200), new_rect)
    new_text = FONT.render("Create New World", True, (255, 255, 255))
    screen.blit(new_text, (new_rect.x + 40, new_rect.y + 10))


# -------------------------------
# INVENTORY BAR
# -------------------------------

def draw_inventory():
    bar_width = 400
    bar_height = 60
    bar_x = (SCREEN_WIDTH - bar_width) // 2
    bar_y = SCREEN_HEIGHT - bar_height - 10

    slot_size = 60
    padding = 5

    for i in range(len(inventory)):
        x = bar_x + i * (slot_size + padding)
        y = bar_y

        block_id = inventory[i]
        color = BLOCKS[block_id]

        pygame.draw.rect(screen, (80, 80, 80), (x, y, slot_size, slot_size))
        pygame.draw.rect(screen, color, (x + 5, y + 5, slot_size - 10, slot_size - 10))

        if i == selected_slot:
            pygame.draw.rect(screen, (255, 255, 255), (x, y, slot_size, slot_size), 3)
        else:
            pygame.draw.rect(screen, (0, 0, 0), (x, y, slot_size, slot_size), 2)


# -------------------------------
# MAIN LOOP
# -------------------------------

running = True
while running:
    screen.fill((0, 0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # -----------------------
        # MENU EVENTS
        # -----------------------
        if state == "menu":

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()

                # Scroll
                if event.button == 4:
                    scroll_offset += scroll_speed
                if event.button == 5:
                    scroll_offset -= scroll_speed

                # Click world
                y = 120 + scroll_offset
                for world_file in get_world_list():
                    rect = pygame.Rect(200, y, 400, 40)
                    if rect.collidepoint((mx, my)):
                        world = load_world(world_file)
                        state = "game"
                    y += 60

                # Create new world
                new_rect = pygame.Rect(200, SCREEN_HEIGHT - 100, 400, 50)
                if new_rect.collidepoint((mx, my)):
                    world = new_world()
                    save_world("new_world.json", world)
                    state = "game"

        # -----------------------
        # GAME EVENTS
        # -----------------------
        if state == "game":

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()

                # Prevent clicking on inventory bar
                if my < SCREEN_HEIGHT - 80:
                    grid_x = (mx // TILE_SIZE) + camera_x
                    grid_y = (my // TILE_SIZE) + camera_y

                    if 0 <= grid_x < WORLD_WIDTH and 0 <= grid_y < WORLD_HEIGHT:
                        if event.button == 1:
                            world[grid_y][grid_x] = inventory[selected_slot]
                        if event.button == 3:
                            world[grid_y][grid_x] = 0

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1: selected_slot = 0
                if event.key == pygame.K_2: selected_slot = 1
                if event.key == pygame.K_3: selected_slot = 2
                if event.key == pygame.K_4: selected_slot = 3
                if event.key == pygame.K_5: selected_slot = 4

                if event.key == pygame.K_s:
                    save_world("autosave.json", world)

                if event.key == pygame.K_ESCAPE:
                    state = "menu"

    # -----------------------
    # GAME LOGIC
    # -----------------------
    if state == "game":
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]: camera_y -= 1
        if keys[pygame.K_s]: camera_y += 1
        if keys[pygame.K_a]: camera_x -= 1
        if keys[pygame.K_d]: camera_x += 1

        # Draw world
        for y in range(SCREEN_HEIGHT // TILE_SIZE + 1):
            for x in range(SCREEN_WIDTH // TILE_SIZE + 1):
                wx = x + camera_x
                wy = y + camera_y

                if 0 <= wx < WORLD_WIDTH and 0 <= wy < WORLD_HEIGHT:
                    block = world[wy][wx]
                    color = BLOCKS[block]

                    pygame.draw.rect(
                        screen,
                        color,
                        (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                    )

                    pygame.draw.rect(
                        screen,
                        (30, 30, 30),
                        (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE),
                        1
                    )

        draw_inventory()

    # -----------------------
    # MENU DRAW
    # -----------------------
    if state == "menu":
        draw_menu()

    pygame.display.flip()
    clock.tick(60)

pygame.quit()


