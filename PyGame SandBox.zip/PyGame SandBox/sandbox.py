import pygame
import json

pygame.init()

# --- SETTINGS ---
TILE_SIZE = 32
WORLD_WIDTH = 100
WORLD_HEIGHT = 100
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame Sandbox")

clock = pygame.time.Clock()

# --- BLOCK COLORS ---
BLOCKS = {
    0: (0, 0, 0),          # empty
    1: (139, 69, 19),      # dirt
    2: (34, 139, 34),      # grass
    3: (128, 128, 128),    # stone
    4: (194, 178, 128),    # sand
    5: (0, 0, 255)         # water
}

# Inventory slots (block IDs)
inventory = [1, 2, 3, 4, 5]
selected_slot = 0  # index 0–4

# --- WORLD SETUP ---
world = [[0 for _ in range(WORLD_WIDTH)] for _ in range(WORLD_HEIGHT)]

camera_x = 0
camera_y = 0

# --- SAVE WORLD ---
def save_world():
    data = {"world": world}
    with open("world.json", "w") as f:
        json.dump(data, f)
    print("World saved!")

# --- LOAD WORLD ---
def load_world():
    global world
    try:
        with open("world.json", "r") as f:
            data = json.load(f)
            world = data["world"]
        print("World loaded!")
    except:
        print("No world.json found!")

# --- DRAW INVENTORY BAR ---
def draw_inventory():
    bar_width = 400
    bar_height = 60
    bar_x = (SCREEN_WIDTH - bar_width) // 2
    bar_y = SCREEN_HEIGHT - bar_height - 10

    slot_size = 60
    padding = 5

    for i in range(len(inventory)):
        x = bar_x + i * (slot_size + padding)
        y = bar_y

        block_id = inventory[i]
        color = BLOCKS[block_id]

        # Slot background
        pygame.draw.rect(screen, (80, 80, 80), (x, y, slot_size, slot_size))
        pygame.draw.rect(screen, color, (x + 5, y + 5, slot_size - 10, slot_size - 10))

        # Highlight selected slot
        if i == selected_slot:
            pygame.draw.rect(screen, (255, 255, 255), (x, y, slot_size, slot_size), 3)
        else:
            pygame.draw.rect(screen, (0, 0, 0), (x, y, slot_size, slot_size), 2)

# --- MAIN LOOP ---
running = True
while running:
    screen.fill((50, 50, 50))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # Mouse placing/removing
        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = pygame.mouse.get_pos()

            # Prevent placing blocks on the inventory bar
            if my < SCREEN_HEIGHT - 80:
                grid_x = (mx // TILE_SIZE) + camera_x
                grid_y = (my // TILE_SIZE) + camera_y

                if 0 <= grid_x < WORLD_WIDTH and 0 <= grid_y < WORLD_HEIGHT:
                    if event.button == 1:  # left click = place
                        world[grid_y][grid_x] = inventory[selected_slot]
                    if event.button == 3:  # right click = erase
                        world[grid_y][grid_x] = 0

        # Number keys to switch inventory slot
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_1: selected_slot = 0
            if event.key == pygame.K_2: selected_slot = 1
            if event.key == pygame.K_3: selected_slot = 2
            if event.key == pygame.K_4: selected_slot = 3
            if event.key == pygame.K_5: selected_slot = 4

            if event.key == pygame.K_s:
                save_world()
            if event.key == pygame.K_l:
                load_world()

    # Camera movement
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]: camera_y -= 1
    if keys[pygame.K_s]: camera_y += 1
    if keys[pygame.K_a]: camera_x -= 1
    if keys[pygame.K_d]: camera_x += 1

    # Draw world
    for y in range(SCREEN_HEIGHT // TILE_SIZE + 1):
        for x in range(SCREEN_WIDTH // TILE_SIZE + 1):
            wx = x + camera_x
            wy = y + camera_y

            if 0 <= wx < WORLD_WIDTH and 0 <= wy < WORLD_HEIGHT:
                block = world[wy][wx]
                color = BLOCKS[block]

                pygame.draw.rect(
                    screen,
                    color,
                    (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                )

                # Grid lines
                pygame.draw.rect(
                    screen,
                    (30, 30, 30),
                    (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE),
                    1
                )

    # Draw inventory bar
    draw_inventory()

    pygame.display.flip()
    clock.tick(60)

pygame.quit()

